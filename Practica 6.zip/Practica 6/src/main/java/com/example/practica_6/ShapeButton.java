package com.example.practica_6;

import javafx.scene.control.Button;

public class ShapeButton extends Button {

    public ShapeButton(String text) {

        super(text);

        setPrefSize(80, 80);
        setMinSize(80, 80);
        setMaxSize(80, 80);

        setStyle(
                "-fx-background-radius: 50%;" +
                        "-fx-border-radius: 50%;" +
                        "-fx-background-color: #4267B2;" +
                        "-fx-text-fill: white;" +
                        "-fx-font-weight: bold;"
        );
    }
}