package com.example.practica_6;

import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class ImageButton extends Button {

    public ImageButton(String imagePath) {

        Image image = new Image(
                getClass().getResourceAsStream(imagePath)
        );

        ImageView imageView = new ImageView(image);

        imageView.setFitWidth(30);
        imageView.setFitHeight(30);
        imageView.setPreserveRatio(true);

        setGraphic(imageView);

        setStyle(
                "-fx-background-color: transparent;" +
                        "-fx-cursor: hand;"
        );
    }
}