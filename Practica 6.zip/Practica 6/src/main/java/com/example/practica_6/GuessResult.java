package com.example.practica_6;

public class GuessResult {

    private boolean correct;
    private boolean valid;
    private String message;
    private int attempts;

    public GuessResult(boolean correct, boolean valid,
                       String message, int attempts) {
        this.correct = correct;
        this.valid = valid;
        this.message = message;
        this.attempts = attempts;
    }

    public boolean isCorrect() {
        return correct;
    }

    public boolean isValid() {
        return valid;
    }

    public String getMessage() {
        return message;
    }

    public int getAttempts() {
        return attempts;
    }
}