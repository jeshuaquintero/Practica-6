package com.example.practica_6;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Locale;
import java.util.Random;

public class BetweenleAPI {

    private HashMap<String, WordData> spanishDictionary;
    private HashMap<String, WordData> englishDictionary;

    private HashSet<String> usedLetters;
    private ArrayList<Attempt> history;
    private ArrayList<String> roundWords;

    private String language;
    private String secretWord;

    private int difficulty;
    private int attempts;
    private int lowerIndex;
    private int upperIndex;

    private boolean gameFinished;

    public BetweenleAPI() {

        spanishDictionary = new HashMap<>();
        englishDictionary = new HashMap<>();

        usedLetters = new HashSet<>();
        history = new ArrayList<>();
        roundWords = new ArrayList<>();

        loadDictionary("es");
        loadDictionary("en");
    }

    // Carga los diccionarios originales.
    private void loadDictionary(String file) {

        String path = "/com/example/practica_6/dictionaries/"
                + file + ".txt";

        InputStream input = getClass().getResourceAsStream(path);

        if (input == null) {
            throw new IllegalStateException(
                    "No se encontró el diccionario: " + path
            );
        }

        HashMap<String, WordData> dictionary;

        if (file.equals("es")) {
            dictionary = spanishDictionary;
        } else {
            dictionary = englishDictionary;
        }

        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(input, StandardCharsets.UTF_8))) {

            String line;

            while ((line = reader.readLine()) != null) {

                line = line.trim().replace("\uFEFF", "");

                if (line.isEmpty()) {
                    continue;
                }

                String word;
                String definition = "Definición no disponible.";

                if (line.contains("|")) {

                    String[] parts = line.split("\\|", 2);

                    word = normalize(parts[0]);

                    if (parts.length > 1 && !parts[1].trim().isEmpty()) {
                        definition = parts[1].trim();
                    }

                } else {

                    String[] parts = line.split("\\s+");

                    word = normalize(parts[0]);
                }

                if (!word.isEmpty() && word.matches("[\\p{L}]+")) {

                    dictionary.put(
                            word,
                            new WordData(word, definition)
                    );
                }
            }

        } catch (IOException e) {
            throw new IllegalStateException(
                    "Error al cargar el diccionario: " + file, e
            );
        }
    }

    // Obtiene la ruta de los diccionarios originales del proyecto.
    private Path getSavedDictionaryPath(String file) {

        return Paths.get(
                "src",
                "main",
                "resources",
                "com",
                "example",
                "practica_6",
                "dictionaries",
                file + ".txt"
        );
    }

    // Inicia una nueva partida.
    public void startGame(String language, int difficulty) {

        this.language = language.toLowerCase(Locale.ROOT);
        this.difficulty = difficulty;

        if (difficulty < 5 || difficulty > 7) {
            throw new IllegalArgumentException(
                    "La dificultad debe ser de 5, 6 o 7 letras."
            );
        }

        attempts = 0;
        gameFinished = false;

        history.clear();
        usedLetters.clear();

        rebuildRoundWords();

        if (roundWords.size() < 2) {
            throw new IllegalStateException(
                    "No hay suficientes palabras para esta dificultad."
            );
        }

        Random random = new Random();

        int randomIndex = random.nextInt(roundWords.size());

        secretWord = roundWords.get(randomIndex);

        lowerIndex = 0;
        upperIndex = roundWords.size() - 1;
    }

    // Obtiene el diccionario del idioma seleccionado.
    private HashMap<String, WordData> getDictionary() {

        if (language.equals("español")
                || language.equals("es")) {
            return spanishDictionary;
        }

        return englishDictionary;
    }

    // Construye la lista de palabras de la ronda.
    private void rebuildRoundWords() {

        HashMap<String, WordData> dictionary = getDictionary();

        roundWords.clear();

        dictionary.values().stream()
                .filter(word -> word.getLength() == difficulty)
                .forEach(word -> roundWords.add(word.getWord()));

        roundWords.sort(String::compareTo);
    }

    // Recibe y comprueba una palabra del jugador.
    public GuessResult submitGuess(String input) {

        if (gameFinished) {
            return new GuessResult(
                    false, false,
                    "La partida ha terminado.", attempts
            );
        }

        String guess = normalize(input);

        if (guess.isEmpty()) {
            return new GuessResult(
                    false, false, "Escribe una palabra.", attempts
            );
        }

        if (guess.length() != difficulty) {
            return new GuessResult(
                    false, false,
                    "La palabra debe tener " + difficulty + " letras.",
                    attempts
            );
        }

        if (!guess.matches("[\\p{L}]+")) {
            return new GuessResult(
                    false, false,
                    "La palabra solo debe contener letras.", attempts
            );
        }

        // Comprueba si la palabra ya fue utilizada.
        for (Attempt attempt : history) {

            if (attempt.getWord().equals(guess)) {
                return new GuessResult(
                        false, false,
                        "Ya utilizaste esa palabra.", attempts
                );
            }
        }

        String lowerWord = roundWords.get(lowerIndex);
        String upperWord = roundWords.get(upperIndex);

        // Comprueba que la palabra esté dentro del rango.
        if (guess.compareTo(lowerWord) < 0
                || guess.compareTo(upperWord) > 0) {

            return new GuessResult(
                    false, false,
                    "La palabra debe estar entre "
                            + lowerWord.toUpperCase()
                            + " y "
                            + upperWord.toUpperCase() + ".",
                    attempts
            );
        }

        HashMap<String, WordData> dictionary = getDictionary();

        // Agrega la palabra si todavía no existe.
        if (!dictionary.containsKey(guess)) {
            addWord(guess, "");
        }

        // Inserta la palabra en orden alfabético.
        int position = Collections.binarySearch(roundWords, guess);

        if (position < 0) {
            position = -position - 1;
            roundWords.add(position, guess);
        }

        // Actualiza los índices de los límites.
        lowerIndex = roundWords.indexOf(lowerWord);
        upperIndex = roundWords.indexOf(upperWord);

        attempts++;

        // Guarda las letras utilizadas.
        for (int i = 0; i < guess.length(); i++) {
            usedLetters.add(
                    String.valueOf(guess.charAt(i))
            );
        }

        int comparison = guess.compareTo(secretWord);

        boolean correct = comparison == 0;
        String message;

        if (correct) {

            message = "¡Correcto! Encontraste la palabra.";
            gameFinished = true;

        } else if (comparison < 0) {

            message = "La palabra secreta está DESPUÉS de tu intento.";

            lowerIndex = position;

        } else {

            message = "La palabra secreta está ANTES de tu intento.";

            upperIndex = position;
        }

        history.add(new Attempt(
                guess,
                attempts,
                message
        ));

        if (!correct && attempts >= 14) {

            message += " Se terminaron los intentos. "
                    + "La palabra era: " + secretWord;

            gameFinished = true;
        }

        return new GuessResult(
                correct, true, message, attempts
        );
    }

    // Agrega una palabra nueva sin borrar el contenido original.
    public void addWord(String word, String definition) {

        String normalized = normalize(word);

        if (normalized.isEmpty()
                || !normalized.matches("[\\p{L}]+")) {
            return;
        }

        HashMap<String, WordData> dictionary = getDictionary();

        // Evita palabras repetidas.
        if (dictionary.containsKey(normalized)) {
            return;
        }

        // Agrega la palabra al diccionario en memoria.
        dictionary.put(
                normalized,
                new WordData(normalized, "")
        );

        String file = (language.equals("es")
                || language.equals("español")) ? "es" : "en";

        Path path = getSavedDictionaryPath(file);

        try {

            // Lee todas las líneas originales sin modificarlas.
            ArrayList<String> lines = new ArrayList<>();

            if (Files.exists(path)) {
                lines.addAll(
                        Files.readAllLines(path, StandardCharsets.UTF_8)
                );
            }

            // Comprueba si la palabra ya existe en el archivo.
            boolean exists = false;

            for (String line : lines) {

                String existingWord = getWordFromLine(line);

                if (normalize(existingWord).equals(normalized)) {
                    exists = true;
                    break;
                }
            }

            // Agrega únicamente la palabra nueva.
            if (!exists) {
                lines.add(normalized);
            }

            // Ordena las líneas por su palabra,
            // conservando las frecuencias originales.
            lines.sort((line1, line2) -> {

                String word1 = getWordFromLine(line1);
                String word2 = getWordFromLine(line2);

                return normalize(word1).compareTo(normalize(word2));
            });

            // Sobrescribe el archivo con todas sus líneas conservadas.
            Files.write(
                    path,
                    lines,
                    StandardCharsets.UTF_8
            );

            System.out.println(
                    "Palabra agregada al diccionario: " + normalized
            );

        } catch (IOException e) {

            System.out.println("Error al guardar la palabra:");
            e.printStackTrace();
        }
    }

    // Obtiene solamente la palabra de una línea del diccionario.
    private String getWordFromLine(String line) {

        String cleanLine = line.trim();

        if (cleanLine.isEmpty()) {
            return "";
        }

        String firstPart = cleanLine.split("\\s+", 2)[0];

        return firstPart.split("\\|", 2)[0];
    }

    // Pista: muestra la primera letra.
    public String getFirstLetterHint() {

        return "La palabra comienza con: "
                + secretWord.charAt(0);
    }

    // Pista: avanza un 1% desde abajo.
    public String getHintFromBottom() {

        int range = upperIndex - lowerIndex;

        int position = lowerIndex
                + (int) Math.ceil(range * 0.01);

        position = Math.min(position, upperIndex);

        return "Referencia desde abajo: "
                + roundWords.get(position).toUpperCase();
    }

    // Pista: avanza un 1% desde arriba.
    public String getHintFromTop() {

        int range = upperIndex - lowerIndex;

        int position = upperIndex
                - (int) Math.ceil(range * 0.01);

        position = Math.max(position, lowerIndex);

        return "Referencia desde arriba: "
                + roundWords.get(position).toUpperCase();
    }

    // Devuelve el historial de intentos.
    public String getHistoryText() {

        StringBuilder result = new StringBuilder();

        Iterator<Attempt> iterator = history.iterator();

        while (iterator.hasNext()) {

            Attempt attempt = iterator.next();

            result.append("Intento ")
                    .append(attempt.getNumber())
                    .append(": ")
                    .append(attempt.getWord())
                    .append(" - ")
                    .append(attempt.getMessage())
                    .append("\n");
        }

        return result.toString();
    }

    public ArrayList<Attempt> getHistory() {
        return new ArrayList<>(history);
    }

    public HashSet<String> getUsedLetters() {
        return new HashSet<>(usedLetters);
    }

    public int getAttempts() {
        return attempts;
    }

    public int getRemainingAttempts() {
        return 14 - attempts;
    }

    public boolean isGameFinished() {
        return gameFinished;
    }

    public String getSecretWord() {
        return secretWord;
    }

    public int getDictionarySize() {
        return getDictionary().size();
    }

    public WordData getWordData(String word) {
        return getDictionary().get(normalize(word));
    }

    public String getUpperWord() {
        return roundWords.get(upperIndex);
    }

    public String getLowerWord() {
        return roundWords.get(lowerIndex);
    }

    // Calcula la distancia porcentual desde el límite superior.
    public int getUpperDistancePercent() {

        int secretIndex = roundWords.indexOf(secretWord);

        int totalWords = roundWords.size() - 1;

        if (totalWords <= 0) {
            return 0;
        }

        return (int) Math.round(
                Math.abs(upperIndex - secretIndex)
                        * 100.0 / totalWords
        );
    }

    // Calcula la distancia porcentual desde el límite inferior.
    public int getLowerDistancePercent() {

        int secretIndex = roundWords.indexOf(secretWord);

        int totalWords = roundWords.size() - 1;

        if (totalWords <= 0) {
            return 0;
        }

        return (int) Math.round(
                Math.abs(secretIndex - lowerIndex)
                        * 100.0 / totalWords
        );
    }

    // Obtiene la posición porcentual de una palabra.
    public double getWordPositionPercent(String word) {

        String normalized = normalize(word);

        int position = Collections.binarySearch(
                roundWords,
                normalized
        );

        if (position < 0 || roundWords.size() <= 1) {
            return -1;
        }

        return position * 100.0 / (roundWords.size() - 1);
    }

    // Obtiene la posición porcentual de la palabra secreta.
    public double getSecretPositionPercent() {

        int position = roundWords.indexOf(secretWord);

        if (position < 0 || roundWords.size() <= 1) {
            return 0;
        }

        return position * 100.0 / (roundWords.size() - 1);
    }

    public int getSpanishDictionarySize() {
        return spanishDictionary.size();
    }

    public int getEnglishDictionarySize() {
        return englishDictionary.size();
    }

    // Normaliza las palabras.
    private String normalize(String word) {

        if (word == null) {
            return "";
        }

        return word.trim().toLowerCase(Locale.ROOT);
    }
}
