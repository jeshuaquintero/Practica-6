package com.example.practica_6;

public class Attempt {

    private String word;
    private int number;
    private String message;

    public Attempt(String word, int number, String message) {
        this.word = word;
        this.number = number;
        this.message = message;
    }

    public String getWord() {
        return word;
    }

    public int getNumber() {
        return number;
    }

    public String getMessage() {
        return message;
    }
}