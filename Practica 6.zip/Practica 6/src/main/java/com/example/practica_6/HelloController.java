
package com.example.practica_6;

import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;

import java.util.ArrayList;
import java.util.Comparator;

public class HelloController {

    @FXML
    private VBox root;

    private BetweenleAPI game;

    private ComboBox<String> languageBox;
    private ComboBox<String> difficultyBox;

    private TextField guessField;

    private VBox boardBox;
    private VBox attemptsBox;
    private ScrollPane scrollPane;

    private Label attemptsLabel;
    private Label feedbackLabel;
    private Label upperPercent;
    private Label lowerPercent;

    private Button sendButton;
    private Button topButton;
    private Button bottomButton;
    private Button firstLetterButton;

    @FXML
    public void initialize() {
        showMenu();
    }

    // =========================
    // MENÚ PRINCIPAL
    // =========================

    private void showMenu() {

        root.getChildren().clear();
        root.setAlignment(Pos.CENTER);
        root.setSpacing(15);
        root.setStyle("-fx-background-color: #ffffff;");

        Label title = new Label("BETWEENLE");
        title.setStyle(
                "-fx-font-size: 38px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #263b59;"
        );

        Label subtitle = new Label("Guess the secret word");
        subtitle.setStyle(
                "-fx-font-size: 15px;" +
                        "-fx-text-fill: #777777;"
        );

        Label languageTitle = new Label("LANGUAGE");

        languageBox = new ComboBox<>();
        languageBox.getItems().addAll("Español", "English");
        languageBox.setValue("Español");
        languageBox.setPrefWidth(230);

        Label difficultyTitle = new Label("DIFFICULTY");

        difficultyBox = new ComboBox<>();
        difficultyBox.getItems().addAll(
                "Easy - 5 letters",
                "Medium - 6 letters",
                "Hard - 7 letters"
        );

        difficultyBox.setValue("Easy - 5 letters");
        difficultyBox.setPrefWidth(230);

        ShapeButton playButton = new ShapeButton("PLAY");
        playButton.setPrefSize(100, 100);
        playButton.setOnAction(event -> startGame());

        Button helpButton = new Button("HOW TO PLAY");
        helpButton.setStyle(
                "-fx-background-color: transparent;" +
                        "-fx-text-fill: #4267B2;" +
                        "-fx-font-weight: bold;"
        );

        helpButton.setOnAction(event -> showHelp());

        root.getChildren().addAll(
                title,
                subtitle,
                new Label(" "),
                languageTitle,
                languageBox,
                difficultyTitle,
                difficultyBox,
                playButton,
                helpButton
        );
    }

    // =========================
    // INICIAR PARTIDA
    // =========================

    private void startGame() {

        String language = languageBox.getValue().equals("Español")
                ? "es" : "en";

        int difficulty;

        if (difficultyBox.getValue().startsWith("Easy")) {
            difficulty = 5;
        } else if (difficultyBox.getValue().startsWith("Medium")) {
            difficulty = 6;
        } else {
            difficulty = 7;
        }

        game = new BetweenleAPI();
        game.startGame(language, difficulty);

        showGame();
    }

    // =========================
    // PANTALLA DEL JUEGO
    // =========================

    private void showGame() {

        root.getChildren().clear();
        root.setAlignment(Pos.TOP_CENTER);
        root.setSpacing(6);
        root.setStyle("-fx-background-color: #ffffff;");

        HBox header = new HBox(15);
        header.setAlignment(Pos.CENTER);

        Button menuButton = new Button("MENU");
        menuButton.setOnAction(event -> showMenu());

        Label title = new Label("BETWEENLE");
        title.setStyle(
                "-fx-font-size: 26px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #263b59;"
        );

        Button statisticsButton = new Button("STATISTICS");
        statisticsButton.setOnAction(event -> showStatistics());

        header.getChildren().addAll(
                menuButton,
                title,
                statisticsButton
        );

        Label subtitle = new Label(
                "Find the secret word between the two words"
        );
        subtitle.setStyle(
                "-fx-font-size: 13px;" +
                        "-fx-text-fill: #777777;"
        );

        attemptsLabel = new Label("0 / 14");
        attemptsLabel.setStyle(
                "-fx-font-size: 16px;" +
                        "-fx-font-weight: bold;"
        );

        // Tablero principal.
        boardBox = new VBox(5);
        boardBox.setAlignment(Pos.CENTER);
        boardBox.setMaxWidth(850);
        boardBox.setPrefWidth(850);

        // Lista central de intentos.
        attemptsBox = new VBox(5);
        attemptsBox.setAlignment(Pos.CENTER);
        attemptsBox.setFillWidth(true);

        scrollPane = new ScrollPane(attemptsBox);
        scrollPane.setFitToWidth(true);
        scrollPane.setPrefHeight(125);
        scrollPane.setMinHeight(100);
        scrollPane.setMaxHeight(125);
        scrollPane.setMaxWidth(850);
        scrollPane.setStyle(
                "-fx-background-color: transparent;" +
                        "-fx-background: white;" +
                        "-fx-border-color: transparent;"
        );

        guessField = new TextField();
        guessField.setPromptText("Enter a word...");
        guessField.setPrefWidth(400);
        guessField.setPrefHeight(40);
        guessField.setStyle(
                "-fx-font-size: 14px;" +
                        "-fx-padding: 7px;"
        );

        SoundButton send = new SoundButton(
                "ENTER",
                "/com/example/practica_6/audio/click.wav"
        );

        sendButton = send;
        send.setPrefHeight(36);

        send.setOnAction(event -> submitGuess());
        guessField.setOnAction(event -> submitGuess());

        HBox inputRow = new HBox(10, guessField, send);
        inputRow.setAlignment(Pos.CENTER);

        feedbackLabel = new Label("Good luck!");
        feedbackLabel.setWrapText(true);
        feedbackLabel.setStyle(
                "-fx-font-size: 13px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #263b59;"
        );

        Label hintsTitle = new Label("HINTS");
        hintsTitle.setStyle(
                "-fx-font-size: 15px;" +
                        "-fx-font-weight: bold;"
        );

        topButton = new Button("BOTTOM +1%");
        bottomButton = new Button("TOP +1%");

        topButton.setStyle(
                "-fx-font-size: 12px;" +
                        "-fx-padding: 5px 10px;"
        );

        bottomButton.setStyle(
                "-fx-font-size: 12px;" +
                        "-fx-padding: 5px 10px;"
        );

        ImageButton firstLetter = new ImageButton(
                "/com/example/practica_6/images/hint.png"
        );

        firstLetter.setPrefSize(35, 35);

        firstLetterButton = firstLetter;
        firstLetter.setTooltip(new Tooltip("Show first letter"));

        topButton.setOnAction(event ->
                feedbackLabel.setText(game.getHintFromTop())
        );

        bottomButton.setOnAction(event ->
                feedbackLabel.setText(game.getHintFromBottom())
        );

        firstLetter.setOnAction(event ->
                feedbackLabel.setText(game.getFirstLetterHint())
        );

        HBox hintsRow = new HBox(
                10,
                topButton,
                bottomButton,
                firstLetter
        );
        hintsRow.setAlignment(Pos.CENTER);

        root.getChildren().addAll(
                header,
                subtitle,
                attemptsLabel,
                boardBox,
                inputRow,
                feedbackLabel,
                hintsTitle,
                hintsRow
        );

        refreshBoard();
    }

    // =========================
    // CREAR CASILLAS DE LETRAS
    // =========================

    private HBox createWordTiles(String word, Color color) {

        HBox tiles = new HBox(4);
        tiles.setAlignment(Pos.CENTER);

        for (int i = 0; i < word.length(); i++) {

            Label letter = new Label(
                    String.valueOf(word.charAt(i)).toUpperCase()
            );

            letter.setAlignment(Pos.CENTER);
            letter.setPrefSize(44, 44);
            letter.setMinSize(44, 44);
            letter.setMaxSize(44, 44);

            letter.setStyle(
                    "-fx-background-color: " + toHex(color) + ";" +
                            "-fx-text-fill: white;" +
                            "-fx-font-size: 19px;" +
                            "-fx-font-weight: bold;" +
                            "-fx-background-radius: 5;"
            );

            tiles.getChildren().add(letter);
        }

        return tiles;
    }

    // =========================
    // CONVERTIR COLOR A HEXADECIMAL
    // =========================

    private String toHex(Color color) {

        return String.format(
                "#%02X%02X%02X",
                (int) (color.getRed() * 255),
                (int) (color.getGreen() * 255),
                (int) (color.getBlue() * 255)
        );
    }

    // =========================
    // COLOR SEGÚN PROXIMIDAD
    // =========================

    private Color getAttemptColor(String word) {

        double wordPosition =
                game.getWordPositionPercent(word);

        double secretPosition =
                game.getSecretPositionPercent();

        if (wordPosition < 0) {
            return Color.web("#F2A23A");
        }

        double distance =
                Math.abs(wordPosition - secretPosition);

        // El color cambia de naranja a verde
        // conforme el intento se acerca a la palabra secreta.
        double closeness = 1.0 - Math.min(distance / 20.0, 1.0);

        Color orange = Color.web("#F2A23A");
        Color green = Color.web("#58A66A");

        return orange.interpolate(green, closeness);
    }

    // =========================
    // ACTUALIZAR TABLERO
    // =========================

    private void refreshBoard() {

        boardBox.getChildren().clear();
        attemptsBox.getChildren().clear();

        upperPercent = new Label(
                game.getUpperDistancePercent() + "%"
        );

        lowerPercent = new Label(
                game.getLowerDistancePercent() + "%"
        );

        upperPercent.setStyle(
                "-fx-font-size: 13px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #777777;"
        );

        lowerPercent.setStyle(
                "-fx-font-size: 13px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #777777;"
        );

        // Palabra superior.
        Label upperTitle = new Label("TOP WORD");
        upperTitle.setStyle(
                "-fx-font-size: 13px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #777777;"
        );

        // Se conserva el orden original de las palabras.
        HBox upperTiles = createWordTiles(
                game.getLowerWord(),
                Color.web("#4267B2")
        );

        // Obtener y ordenar los intentos.
        ArrayList<Attempt> attempts = game.getHistory();

        attempts.sort(Comparator.comparing(Attempt::getWord));

        // Mostrar los intentos en el centro.
        for (Attempt attempt : attempts) {

            Color wordColor = getAttemptColor(
                    attempt.getWord()
            );

            if (attempt.getWord().equals(game.getSecretWord())
                    && game.isGameFinished()) {
                wordColor = Color.web("#58A66A");
            }

            HBox wordTiles = createWordTiles(
                    attempt.getWord(),
                    wordColor
            );

            Label direction = new Label(
                    attempt.getMessage()
            );

            direction.setWrapText(true);
            direction.setStyle(
                    "-fx-font-size: 12px;" +
                            "-fx-text-fill: #555555;"
            );

            HBox row = new HBox(
                    12,
                    wordTiles,
                    direction
            );

            row.setAlignment(Pos.CENTER);
            row.setMaxWidth(810);
            row.setMinHeight(55);

            row.setStyle(
                    "-fx-background-color: #fafafa;" +
                            "-fx-padding: 5px;" +
                            "-fx-background-radius: 5;"
            );

            attemptsBox.getChildren().add(row);
        }

        // Palabra inferior.
        Label lowerTitle = new Label("BOTTOM WORD");
        lowerTitle.setStyle(
                "-fx-font-size: 13px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #777777;"
        );

        // Se conserva el orden original de las palabras.
        HBox lowerTiles = createWordTiles(
                game.getUpperWord(),
                Color.web("#4267B2")
        );

        // Cada porcentaje queda debajo de su palabra visual.
        VBox topWordBox = new VBox(
                3,
                upperTitle,
                upperTiles,
                lowerPercent
        );
        topWordBox.setAlignment(Pos.CENTER);

        VBox bottomWordBox = new VBox(
                3,
                lowerTitle,
                lowerTiles,
                upperPercent
        );
        bottomWordBox.setAlignment(Pos.CENTER);

        // Construir el tablero.
        boardBox.getChildren().addAll(
                topWordBox,
                scrollPane,
                bottomWordBox
        );

        attemptsLabel.setText(
                game.getAttempts() + " / 14"
        );
    }

    // =========================
    // ENVIAR PALABRA
    // =========================

    private void submitGuess() {

        String word = guessField.getText().trim();

        if (word.isEmpty()) {
            feedbackLabel.setText("Enter a word first.");
            return;
        }

        GuessResult result = game.submitGuess(word);

        feedbackLabel.setText(result.getMessage());

        guessField.clear();

        refreshBoard();

        if (game.isGameFinished()) {
            finishGame(result.isCorrect());
        }
    }

    // =========================
    // FINALIZAR PARTIDA
    // =========================

    private void finishGame(boolean won) {

        guessField.setDisable(true);
        sendButton.setDisable(true);

        topButton.setDisable(true);
        bottomButton.setDisable(true);
        firstLetterButton.setDisable(true);

        if (won) {
            feedbackLabel.setText(
                    "YOU WIN! Congratulations!"
            );
        } else {
            feedbackLabel.setText(
                    "GAME OVER - The word was: " +
                            game.getSecretWord().toUpperCase()
            );
        }

        Button playAgain = new Button("PLAY AGAIN");
        playAgain.setOnAction(event -> showMenu());

        root.getChildren().add(playAgain);
    }

    // =========================
    // AYUDA
    // =========================

    private void showHelp() {

        Alert alert = new Alert(Alert.AlertType.INFORMATION);

        alert.setTitle("How to play");
        alert.setHeaderText("BETWEENLE");

        alert.setContentText(
                "Guess the secret word!\n\n" +
                        "1. The secret word is alphabetically between two words.\n\n" +
                        "2. Enter a word to narrow the range.\n\n" +
                        "3. The game tells you if the secret word is before or after.\n\n" +
                        "4. Use the hints to find the answer.\n\n" +
                        "5. You have 14 attempts."
        );

        alert.showAndWait();
    }

    // =========================
    // ESTADÍSTICAS
    // =========================

    private void showStatistics() {

        Alert alert = new Alert(Alert.AlertType.INFORMATION);

        alert.setTitle("Statistics");
        alert.setHeaderText("Current game");

        alert.setContentText(
                "Attempts: " + game.getAttempts() +
                        "\nRemaining: " + game.getRemainingAttempts() +
                        "\nLetters used: " + game.getUsedLetters().size()
        );

        alert.showAndWait();
    }
}
