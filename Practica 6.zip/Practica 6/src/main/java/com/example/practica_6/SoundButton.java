package com.example.practica_6;

import javafx.scene.control.Button;
import javafx.scene.media.AudioClip;

public class SoundButton extends Button {

    private AudioClip sound;

    public SoundButton(String text, String audioPath) {

        super(text);

        setStyle(
                "-fx-background-color: #2980B9;" +
                        "-fx-text-fill: white;" +
                        "-fx-background-radius: 10;"
        );

        if (getClass().getResource(audioPath) != null) {
            sound = new AudioClip(
                    getClass().getResource(audioPath).toExternalForm()
            );
        }

        setOnMouseEntered(event -> playSound());

        setOnAction(event -> playSound());
    }

    private void playSound() {

        if (sound != null) {
            sound.play();
        }
    }
}