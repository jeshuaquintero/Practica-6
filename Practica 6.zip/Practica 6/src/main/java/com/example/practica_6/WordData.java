package com.example.practica_6;

public class WordData {

    private String word;
    private String definition;
    private int length;

    public WordData(String word, String definition) {
        this.word = word;
        this.definition = definition;
        this.length = word.length();
    }

    public String getWord() {
        return word;
    }

    public String getDefinition() {
        return definition;
    }

    public int getLength() {
        return length;
    }
}